using Microsoft.EntityFrameworkCore;
using VaR.Domain.Entities;

namespace VaR.Infrastructure.Data;

public class VaRDbContext : DbContext
{
    public VaRDbContext(DbContextOptions<VaRDbContext> options) : base(options) { }

    public DbSet<Ativo> Ativos => Set<Ativo>();
    public DbSet<HistoricoPreco> HistoricoPrecos => Set<HistoricoPreco>();
    public DbSet<Carteira> Carteiras => Set<Carteira>();
    public DbSet<CarteiraItem> CarteiraItens => Set<CarteiraItem>();
    public DbSet<Simulacao> Simulacoes => Set<Simulacao>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.ApplyConfigurationsFromAssembly(typeof(VaRDbContext).Assembly);

        modelBuilder.Entity<Ativo>(e =>
        {
            e.ToTable("Ativos");
            e.HasKey(a => a.AtivoId);
            e.Property(a => a.Codigo).HasMaxLength(20).IsRequired();
            e.HasIndex(a => a.Codigo).IsUnique();
            e.Property(a => a.Nome).HasMaxLength(150).IsRequired();
            e.Property(a => a.Moeda).HasMaxLength(3).IsRequired();
            e.Property(a => a.RetornoEsperadoAA).HasColumnType("decimal(9,6)");
            e.Property(a => a.VolatilidadeAA).HasColumnType("decimal(9,6)");
        });

        modelBuilder.Entity<HistoricoPreco>(e =>
        {
            e.ToTable("Historico_Precos");
            e.HasKey(h => h.HistoricoId);
            e.Property(h => h.PrecoFechamento).HasColumnType("decimal(18,6)");
            e.HasIndex(h => new { h.AtivoId, h.DataReferencia }).IsUnique();
            e.HasOne(h => h.Ativo).WithMany(a => a.Historico).HasForeignKey(h => h.AtivoId);
        });

        modelBuilder.Entity<Carteira>(e =>
        {
            e.ToTable("Carteiras");
            e.HasKey(c => c.CarteiraId);
            e.Property(c => c.NomeCarteira).HasMaxLength(150).IsRequired();
            e.Property(c => c.ValorTotal).HasColumnType("decimal(18,2)");
        });

        modelBuilder.Entity<CarteiraItem>(e =>
        {
            e.ToTable("Carteira_Itens");
            e.HasKey(i => i.CarteiraItemId);
            e.Property(i => i.Peso).HasColumnType("decimal(9,6)");
            e.HasIndex(i => new { i.CarteiraId, i.AtivoId }).IsUnique();
            e.HasOne(i => i.Carteira).WithMany(c => c.Itens)
                .HasForeignKey(i => i.CarteiraId).OnDelete(DeleteBehavior.Cascade);
            e.HasOne(i => i.Ativo).WithMany()
                .HasForeignKey(i => i.AtivoId).OnDelete(DeleteBehavior.Restrict);
        });

        modelBuilder.Entity<Simulacao>(e =>
        {
            e.ToTable("Simulacoes");
            e.HasKey(s => s.SimulacaoId);
            e.Property(s => s.NivelConfianca).HasColumnType("decimal(5,4)");
            e.Property(s => s.ValorCarteira).HasColumnType("decimal(18,2)");
            e.Property(s => s.VaRAbsoluto).HasColumnType("decimal(18,2)");
            e.Property(s => s.VaRPercentual).HasColumnType("decimal(9,6)");
            e.Property(s => s.CVaR).HasColumnType("decimal(18,2)");
            e.HasOne(s => s.Carteira).WithMany(c => c.Simulacoes).HasForeignKey(s => s.CarteiraId);
        });
    }
}
