using Microsoft.EntityFrameworkCore;
using VaR.Application.Interfaces;
using VaR.Domain.Entities;
using VaR.Infrastructure.Data;

namespace VaR.Infrastructure.Repositories;

public class CarteiraRepository : ICarteiraRepository
{
    private readonly VaRDbContext _context;
    public CarteiraRepository(VaRDbContext context) => _context = context;

    public async Task<Carteira?> GetByIdAsync(int carteiraId, bool incluirItens = true, CancellationToken ct = default)
    {
        var query = _context.Carteiras.AsQueryable();
        if (incluirItens)
            query = query.Include(c => c.Itens).ThenInclude(i => i.Ativo);

        return await query.FirstOrDefaultAsync(c => c.CarteiraId == carteiraId, ct);
    }

    public async Task<IReadOnlyList<Carteira>> GetAllAsync(CancellationToken ct = default) =>
        await _context.Carteiras.Include(c => c.Itens).ThenInclude(i => i.Ativo).ToListAsync(ct);

    public async Task<Carteira> AddAsync(Carteira carteira, CancellationToken ct = default)
    {
        _context.Carteiras.Add(carteira);
        await _context.SaveChangesAsync(ct);
        return carteira;
    }

    public async Task UpdateAsync(Carteira carteira, CancellationToken ct = default)
    {
        carteira.DataAtualizacao = DateTime.UtcNow;
        _context.Carteiras.Update(carteira);
        await _context.SaveChangesAsync(ct);
    }

    public async Task DeleteAsync(int carteiraId, CancellationToken ct = default)
    {
        var carteira = await _context.Carteiras.FindAsync(new object?[] { carteiraId }, ct);
        if (carteira is null) return;
        _context.Carteiras.Remove(carteira);
        await _context.SaveChangesAsync(ct);
    }
}
