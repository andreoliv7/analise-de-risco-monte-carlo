using Microsoft.EntityFrameworkCore;
using VaR.Application.Interfaces;
using VaR.Domain.Entities;
using VaR.Infrastructure.Data;

namespace VaR.Infrastructure.Repositories;

public class SimulacaoRepository : ISimulacaoRepository
{
    private readonly VaRDbContext _context;
    public SimulacaoRepository(VaRDbContext context) => _context = context;

    public async Task<Simulacao> AddAsync(Simulacao simulacao, CancellationToken ct = default)
    {
        _context.Simulacoes.Add(simulacao);
        await _context.SaveChangesAsync(ct);
        return simulacao;
    }

    public async Task<IReadOnlyList<Simulacao>> GetByCarteiraIdAsync(int carteiraId, CancellationToken ct = default) =>
        await _context.Simulacoes
            .Where(s => s.CarteiraId == carteiraId)
            .OrderByDescending(s => s.DataExecucao)
            .ToListAsync(ct);

    public async Task<Simulacao?> GetByIdAsync(long simulacaoId, CancellationToken ct = default) =>
        await _context.Simulacoes.FindAsync(new object?[] { simulacaoId }, ct);
}
