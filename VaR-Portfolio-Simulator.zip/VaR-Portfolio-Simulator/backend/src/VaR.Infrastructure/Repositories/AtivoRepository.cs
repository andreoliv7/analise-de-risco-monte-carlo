using Microsoft.EntityFrameworkCore;
using VaR.Application.Interfaces;
using VaR.Domain.Entities;
using VaR.Infrastructure.Data;

namespace VaR.Infrastructure.Repositories;

public class AtivoRepository : IAtivoRepository
{
    private readonly VaRDbContext _context;
    public AtivoRepository(VaRDbContext context) => _context = context;

    public async Task<Ativo?> GetByIdAsync(int ativoId, CancellationToken ct = default) =>
        await _context.Ativos.FindAsync(new object?[] { ativoId }, ct);

    public async Task<IReadOnlyList<Ativo>> GetAllAsync(CancellationToken ct = default) =>
        await _context.Ativos.Where(a => a.Ativo_).ToListAsync(ct);

    public async Task<IReadOnlyList<Ativo>> GetByIdsAsync(IEnumerable<int> ids, CancellationToken ct = default) =>
        await _context.Ativos.Where(a => ids.Contains(a.AtivoId)).ToListAsync(ct);

    public async Task<Ativo> AddAsync(Ativo ativo, CancellationToken ct = default)
    {
        _context.Ativos.Add(ativo);
        await _context.SaveChangesAsync(ct);
        return ativo;
    }

    public async Task UpdateAsync(Ativo ativo, CancellationToken ct = default)
    {
        _context.Ativos.Update(ativo);
        await _context.SaveChangesAsync(ct);
    }

    public async Task DeleteAsync(int ativoId, CancellationToken ct = default)
    {
        var ativo = await _context.Ativos.FindAsync(new object?[] { ativoId }, ct);
        if (ativo is null) return;
        ativo.Ativo_ = false; // soft delete: mantém integridade referencial com carteiras existentes
        await _context.SaveChangesAsync(ct);
    }

    public async Task<IReadOnlyList<HistoricoPreco>> GetHistoricoAsync(int ativoId, CancellationToken ct = default) =>
        await _context.HistoricoPrecos
            .Where(h => h.AtivoId == ativoId)
            .OrderBy(h => h.DataReferencia)
            .ToListAsync(ct);
}
