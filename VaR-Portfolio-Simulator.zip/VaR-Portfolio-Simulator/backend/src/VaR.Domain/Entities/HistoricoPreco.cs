namespace VaR.Domain.Entities;

/// <summary>
/// Cotação histórica de um ativo em uma data de referência,
/// usada para estimar retorno médio, volatilidade e correlação.
/// </summary>
public class HistoricoPreco
{
    public long HistoricoId { get; set; }
    public int AtivoId { get; set; }
    public Ativo? Ativo { get; set; }
    public DateOnly DataReferencia { get; set; }
    public decimal PrecoFechamento { get; set; }
}
