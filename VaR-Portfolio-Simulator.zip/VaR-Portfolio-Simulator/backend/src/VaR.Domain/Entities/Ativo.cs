using VaR.Domain.Enums;

namespace VaR.Domain.Entities;

/// <summary>
/// Representa um ativo financeiro cadastrado no sistema (renda fixa,
/// ação, derivativo, câmbio, cripto).
/// </summary>
public class Ativo
{
    public int AtivoId { get; set; }
    public string Codigo { get; set; } = string.Empty;
    public string Nome { get; set; } = string.Empty;
    public TipoAtivo TipoAtivo { get; set; }
    public string Moeda { get; set; } = "BRL";

    /// <summary>Retorno esperado anualizado (usado sobretudo em renda fixa).</summary>
    public decimal? RetornoEsperadoAA { get; set; }

    /// <summary>Volatilidade anualizada estimada a partir do histórico de preços.</summary>
    public decimal? VolatilidadeAA { get; set; }

    public DateTime DataCadastro { get; set; } = DateTime.UtcNow;
    public bool Ativo_ { get; set; } = true;

    public ICollection<HistoricoPreco> Historico { get; set; } = new List<HistoricoPreco>();
}
