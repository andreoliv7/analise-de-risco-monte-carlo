namespace VaR.Domain.Entities;

/// <summary>
/// Item de composição de uma carteira: qual ativo entra e com
/// qual peso (participação percentual) dentro da carteira.
/// </summary>
public class CarteiraItem
{
    public int CarteiraItemId { get; set; }
    public int CarteiraId { get; set; }
    public Carteira? Carteira { get; set; }

    public int AtivoId { get; set; }
    public Ativo? Ativo { get; set; }

    /// <summary>Peso do ativo na carteira, de 0 a 1. A soma dos pesos deve ser 1.</summary>
    public decimal Peso { get; set; }

    public decimal? Quantidade { get; set; }
    public decimal? PrecoEntrada { get; set; }
}
