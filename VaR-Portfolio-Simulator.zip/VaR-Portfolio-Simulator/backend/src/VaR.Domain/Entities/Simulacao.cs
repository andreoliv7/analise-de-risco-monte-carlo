namespace VaR.Domain.Entities;

/// <summary>
/// Registro histórico de uma execução de Simulação de Monte Carlo
/// para uma carteira, com os resultados de VaR e CVaR obtidos.
/// </summary>
public class Simulacao
{
    public long SimulacaoId { get; set; }
    public int CarteiraId { get; set; }
    public Carteira? Carteira { get; set; }

    public DateTime DataExecucao { get; set; } = DateTime.UtcNow;
    public int NumeroCenarios { get; set; }
    public int HorizonteDias { get; set; }
    public decimal NivelConfianca { get; set; }

    public decimal ValorCarteira { get; set; }
    public decimal VaRAbsoluto { get; set; }
    public decimal VaRPercentual { get; set; }
    public decimal? CVaR { get; set; }
    public decimal? RetornoMedioSimulado { get; set; }
    public long? SeedAleatoria { get; set; }
}
