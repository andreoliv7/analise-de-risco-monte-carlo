namespace VaR.Domain.Entities;

/// <summary>
/// Carteira de investimentos montada pelo usuário, composta por
/// um ou mais ativos (CarteiraItem) com seus respectivos pesos.
/// </summary>
public class Carteira
{
    public int CarteiraId { get; set; }
    public string NomeCarteira { get; set; } = string.Empty;
    public int? UsuarioId { get; set; }
    public decimal ValorTotal { get; set; }
    public DateTime DataCriacao { get; set; } = DateTime.UtcNow;
    public DateTime? DataAtualizacao { get; set; }

    public ICollection<CarteiraItem> Itens { get; set; } = new List<CarteiraItem>();
    public ICollection<Simulacao> Simulacoes { get; set; } = new List<Simulacao>();
}
