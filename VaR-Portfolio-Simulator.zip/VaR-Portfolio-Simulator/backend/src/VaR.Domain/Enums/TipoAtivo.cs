namespace VaR.Domain.Enums;

/// <summary>
/// Classificação do ativo financeiro para fins de precificação
/// e simulação (renda fixa segue modelo determinístico/pouco volátil,
/// derivativos e ações seguem GBM com volatilidade própria).
/// </summary>
public enum TipoAtivo
{
    RendaFixa = 1,
    Acao = 2,
    Derivativo = 3,
    Cambio = 4,
    Cripto = 5
}
