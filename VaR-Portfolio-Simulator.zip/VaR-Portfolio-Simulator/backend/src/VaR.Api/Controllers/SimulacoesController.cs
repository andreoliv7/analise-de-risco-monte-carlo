using Microsoft.AspNetCore.Mvc;
using VaR.Application.DTOs;
using VaR.Application.Services;

namespace VaR.Api.Controllers;

/// <summary>Execução e histórico de Simulações de Monte Carlo para cálculo de VaR.</summary>
[ApiController]
[Route("api/[controller]")]
[Produces("application/json")]
public class SimulacoesController : ControllerBase
{
    private readonly CarteiraService _carteiraService;
    public SimulacoesController(CarteiraService carteiraService) => _carteiraService = carteiraService;

    /// <summary>
    /// Executa uma Simulação de Monte Carlo sobre a carteira informada e
    /// retorna o Value at Risk (VaR), o CVaR (Expected Shortfall) e o
    /// histograma de retornos simulados para plotagem no dashboard.
    /// </summary>
    /// <param name="request">
    /// Parâmetros da simulação: carteira, número de cenários (ex.: 10000),
    /// horizonte em dias úteis e nível de confiança (ex.: 0.95 para 95%).
    /// </param>
    [HttpPost("simular")]
    [ProducesResponseType(typeof(SimulacaoResultDto), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<IActionResult> Simular([FromBody] SimulacaoRequestDto request, CancellationToken ct)
    {
        try
        {
            var resultado = await _carteiraService.ExecutarSimulacaoAsync(request, ct);
            return Ok(resultado);
        }
        catch (KeyNotFoundException ex)
        {
            return NotFound(ex.Message);
        }
        catch (ArgumentException ex)
        {
            return BadRequest(ex.Message);
        }
        catch (InvalidOperationException ex)
        {
            return BadRequest(ex.Message);
        }
    }
}
