using Microsoft.AspNetCore.Mvc;
using VaR.Application.DTOs;
using VaR.Application.Interfaces;
using VaR.Domain.Entities;
using VaR.Domain.Enums;

namespace VaR.Api.Controllers;

/// <summary>Cadastro de ativos financeiros (renda fixa, ações, derivativos, câmbio, cripto).</summary>
[ApiController]
[Route("api/[controller]")]
[Produces("application/json")]
public class AtivosController : ControllerBase
{
    private readonly IAtivoRepository _repository;
    public AtivosController(IAtivoRepository repository) => _repository = repository;

    /// <summary>Lista todos os ativos cadastrados e ativos (não excluídos).</summary>
    [HttpGet]
    [ProducesResponseType(typeof(IEnumerable<AtivoDto>), StatusCodes.Status200OK)]
    public async Task<IActionResult> GetAll(CancellationToken ct)
    {
        var ativos = await _repository.GetAllAsync(ct);
        return Ok(ativos.Select(ToDto));
    }

    /// <summary>Obtém um ativo pelo Id.</summary>
    [HttpGet("{id:int}")]
    [ProducesResponseType(typeof(AtivoDto), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<IActionResult> GetById(int id, CancellationToken ct)
    {
        var ativo = await _repository.GetByIdAsync(id, ct);
        return ativo is null ? NotFound() : Ok(ToDto(ativo));
    }

    /// <summary>Cadastra um novo ativo financeiro.</summary>
    [HttpPost]
    [ProducesResponseType(typeof(AtivoDto), StatusCodes.Status201Created)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    public async Task<IActionResult> Create([FromBody] AtivoCreateDto dto, CancellationToken ct)
    {
        if (!Enum.TryParse<TipoAtivo>(dto.TipoAtivo, ignoreCase: true, out var tipo))
            return BadRequest($"TipoAtivo inválido: {dto.TipoAtivo}");

        var ativo = new Ativo
        {
            Codigo = dto.Codigo,
            Nome = dto.Nome,
            TipoAtivo = tipo,
            Moeda = dto.Moeda,
            RetornoEsperadoAA = dto.RetornoEsperadoAA,
            VolatilidadeAA = dto.VolatilidadeAA
        };
        var criado = await _repository.AddAsync(ativo, ct);
        return CreatedAtAction(nameof(GetById), new { id = criado.AtivoId }, ToDto(criado));
    }

    /// <summary>Atualiza os dados de um ativo existente.</summary>
    [HttpPut("{id:int}")]
    [ProducesResponseType(StatusCodes.Status204NoContent)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<IActionResult> Update(int id, [FromBody] AtivoCreateDto dto, CancellationToken ct)
    {
        var ativo = await _repository.GetByIdAsync(id, ct);
        if (ativo is null) return NotFound();

        if (!Enum.TryParse<TipoAtivo>(dto.TipoAtivo, ignoreCase: true, out var tipo))
            return BadRequest($"TipoAtivo inválido: {dto.TipoAtivo}");

        ativo.Codigo = dto.Codigo;
        ativo.Nome = dto.Nome;
        ativo.TipoAtivo = tipo;
        ativo.Moeda = dto.Moeda;
        ativo.RetornoEsperadoAA = dto.RetornoEsperadoAA;
        ativo.VolatilidadeAA = dto.VolatilidadeAA;

        await _repository.UpdateAsync(ativo, ct);
        return NoContent();
    }

    /// <summary>Remove (logicamente) um ativo do cadastro.</summary>
    [HttpDelete("{id:int}")]
    [ProducesResponseType(StatusCodes.Status204NoContent)]
    public async Task<IActionResult> Delete(int id, CancellationToken ct)
    {
        await _repository.DeleteAsync(id, ct);
        return NoContent();
    }

    private static AtivoDto ToDto(Ativo a) => new(
        a.AtivoId, a.Codigo, a.Nome, a.TipoAtivo.ToString(), a.Moeda, a.RetornoEsperadoAA, a.VolatilidadeAA);
}
