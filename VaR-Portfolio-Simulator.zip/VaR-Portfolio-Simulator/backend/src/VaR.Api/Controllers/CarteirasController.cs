using Microsoft.AspNetCore.Mvc;
using VaR.Application.DTOs;
using VaR.Application.Interfaces;
using VaR.Domain.Entities;

namespace VaR.Api.Controllers;

/// <summary>CRUD de carteiras de investimento (conjunto de ativos com pesos).</summary>
[ApiController]
[Route("api/[controller]")]
[Produces("application/json")]
public class CarteirasController : ControllerBase
{
    private readonly ICarteiraRepository _repository;
    public CarteirasController(ICarteiraRepository repository) => _repository = repository;

    /// <summary>Lista todas as carteiras cadastradas.</summary>
    [HttpGet]
    [ProducesResponseType(typeof(IEnumerable<CarteiraDto>), StatusCodes.Status200OK)]
    public async Task<IActionResult> GetAll(CancellationToken ct)
    {
        var carteiras = await _repository.GetAllAsync(ct);
        return Ok(carteiras.Select(ToDto));
    }

    /// <summary>Obtém uma carteira específica, com seus ativos e pesos.</summary>
    [HttpGet("{id:int}")]
    [ProducesResponseType(typeof(CarteiraDto), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<IActionResult> GetById(int id, CancellationToken ct)
    {
        var carteira = await _repository.GetByIdAsync(id, incluirItens: true, ct);
        return carteira is null ? NotFound() : Ok(ToDto(carteira));
    }

    /// <summary>Cria uma nova carteira com a composição de ativos e pesos informada.</summary>
    /// <remarks>A soma dos pesos dos itens deve ser igual a 1 (100%).</remarks>
    [HttpPost]
    [ProducesResponseType(typeof(CarteiraDto), StatusCodes.Status201Created)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    public async Task<IActionResult> Create([FromBody] CarteiraCreateDto dto, CancellationToken ct)
    {
        var validationError = ValidarPesos(dto.Itens);
        if (validationError is not null) return BadRequest(validationError);

        var carteira = new Carteira
        {
            NomeCarteira = dto.NomeCarteira,
            ValorTotal = dto.ValorTotal,
            Itens = dto.Itens.Select(i => new CarteiraItem { AtivoId = i.AtivoId, Peso = i.Peso }).ToList()
        };

        var criada = await _repository.AddAsync(carteira, ct);
        return CreatedAtAction(nameof(GetById), new { id = criada.CarteiraId }, ToDto(criada));
    }

    /// <summary>Atualiza nome, valor e composição de uma carteira existente.</summary>
    [HttpPut("{id:int}")]
    [ProducesResponseType(StatusCodes.Status204NoContent)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<IActionResult> Update(int id, [FromBody] CarteiraUpdateDto dto, CancellationToken ct)
    {
        var carteira = await _repository.GetByIdAsync(id, incluirItens: true, ct);
        if (carteira is null) return NotFound();

        var validationError = ValidarPesos(dto.Itens);
        if (validationError is not null) return BadRequest(validationError);

        carteira.NomeCarteira = dto.NomeCarteira;
        carteira.ValorTotal = dto.ValorTotal;
        carteira.Itens.Clear();
        foreach (var i in dto.Itens)
            carteira.Itens.Add(new CarteiraItem { AtivoId = i.AtivoId, Peso = i.Peso });

        await _repository.UpdateAsync(carteira, ct);
        return NoContent();
    }

    /// <summary>Remove uma carteira e seus itens associados.</summary>
    [HttpDelete("{id:int}")]
    [ProducesResponseType(StatusCodes.Status204NoContent)]
    public async Task<IActionResult> Delete(int id, CancellationToken ct)
    {
        await _repository.DeleteAsync(id, ct);
        return NoContent();
    }

    private static string? ValidarPesos(List<CarteiraItemDto> itens)
    {
        if (itens is null || itens.Count == 0) return "A carteira precisa conter ao menos um ativo.";
        var soma = itens.Sum(i => i.Peso);
        if (Math.Abs(soma - 1m) > 0.0001m) return $"A soma dos pesos deve ser 1 (100%). Valor recebido: {soma}.";
        return null;
    }

    private static CarteiraDto ToDto(Carteira c) => new(
        c.CarteiraId,
        c.NomeCarteira,
        c.ValorTotal,
        c.DataCriacao,
        c.Itens.Select(i => new CarteiraItemDto(i.AtivoId, i.Ativo?.Codigo, i.Peso)).ToList()
    );
}
