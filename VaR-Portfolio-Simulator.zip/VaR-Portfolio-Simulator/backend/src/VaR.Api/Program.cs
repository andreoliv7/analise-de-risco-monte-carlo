using Microsoft.EntityFrameworkCore;
using Microsoft.OpenApi.Models;
using VaR.Application.Interfaces;
using VaR.Application.Services;
using VaR.Infrastructure.Data;
using VaR.Infrastructure.Repositories;

var builder = WebApplication.CreateBuilder(args);

// ------------------------------------------------------------
// Serviços / Injeção de dependência
//
// Repare que registramos as ABSTRAÇÕES (IMonteCarloEngine,
// ICarteiraRepository, etc.) apontando para as implementações
// concretas. O motor de cálculo (MonteCarloEngine) não conhece
// nada sobre ASP.NET — apenas é injetado aqui, na borda da API.
// ------------------------------------------------------------
builder.Services.AddDbContext<VaRDbContext>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection")));

builder.Services.AddScoped<ICarteiraRepository, CarteiraRepository>();
builder.Services.AddScoped<IAtivoRepository, AtivoRepository>();
builder.Services.AddScoped<ISimulacaoRepository, SimulacaoRepository>();
builder.Services.AddScoped<IMonteCarloEngine, MonteCarloEngine>();
builder.Services.AddScoped<CarteiraService>();

builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();

// Swagger / OpenAPI - documentação técnica automática dos endpoints
builder.Services.AddSwaggerGen(options =>
{
    options.SwaggerDoc("v1", new OpenApiInfo
    {
        Title = "VaR Portfolio Simulator API",
        Version = "v1",
        Description = "API para montagem de carteiras de investimento e cálculo de " +
                      "Value at Risk (VaR) via Simulação de Monte Carlo. Suporta ativos " +
                      "de renda fixa e derivativos.",
        Contact = new OpenApiContact { Name = "Equipe de Risco" }
    });

    var xmlFile = $"{System.Reflection.Assembly.GetExecutingAssembly().GetName().Name}.xml";
    var xmlPath = Path.Combine(AppContext.BaseDirectory, xmlFile);
    if (File.Exists(xmlPath))
        options.IncludeXmlComments(xmlPath);
});

var allowedOrigins = builder.Configuration.GetSection("AllowedOrigins").Get<string[]>() ?? Array.Empty<string>();
builder.Services.AddCors(options =>
{
    options.AddPolicy("FrontendPolicy", policy =>
        policy.WithOrigins(allowedOrigins).AllowAnyHeader().AllowAnyMethod());
});

var app = builder.Build();

if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI(c => c.SwaggerEndpoint("/swagger/v1/swagger.json", "VaR Portfolio Simulator API v1"));
}

app.UseHttpsRedirection();
app.UseCors("FrontendPolicy");
app.UseAuthorization();
app.MapControllers();

app.Run();

// Necessário para permitir testes de integração via WebApplicationFactory<Program>
public partial class Program { }
