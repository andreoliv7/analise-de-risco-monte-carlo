using VaR.Application.DTOs;
using VaR.Application.Interfaces;
using VaR.Domain.Entities;
using VaR.Domain.Enums;

namespace VaR.Application.Services;

/// <summary>
/// Orquestra o fluxo de: montar a carteira -> obter parâmetros
/// estatísticos dos ativos -> acionar o IMonteCarloEngine -> persistir
/// e devolver o resultado. Depende apenas de abstrações
/// (ICarteiraRepository, IAtivoRepository, ISimulacaoRepository,
/// IMonteCarloEngine), nunca de implementações concretas — permitindo
/// substituir o motor de cálculo, o banco de dados, etc., sem
/// impactar esta classe (Aberto/Fechado - SOLID: O).
/// </summary>
public sealed class CarteiraService
{
    private readonly ICarteiraRepository _carteiraRepository;
    private readonly IAtivoRepository _ativoRepository;
    private readonly ISimulacaoRepository _simulacaoRepository;
    private readonly IMonteCarloEngine _engine;

    public CarteiraService(
        ICarteiraRepository carteiraRepository,
        IAtivoRepository ativoRepository,
        ISimulacaoRepository simulacaoRepository,
        IMonteCarloEngine engine)
    {
        _carteiraRepository = carteiraRepository;
        _ativoRepository = ativoRepository;
        _simulacaoRepository = simulacaoRepository;
        _engine = engine;
    }

    public async Task<SimulacaoResultDto> ExecutarSimulacaoAsync(SimulacaoRequestDto request, CancellationToken ct = default)
    {
        var carteira = await _carteiraRepository.GetByIdAsync(request.CarteiraId, incluirItens: true, ct)
            ?? throw new KeyNotFoundException($"Carteira {request.CarteiraId} não encontrada.");

        if (carteira.Itens.Count == 0)
            throw new InvalidOperationException("A carteira não possui ativos cadastrados.");

        var ativosIds = carteira.Itens.Select(i => i.AtivoId);
        var ativos = await _ativoRepository.GetByIdsAsync(ativosIds, ct);
        var ativosPorId = ativos.ToDictionary(a => a.AtivoId);

        var assetInputs = carteira.Itens.Select(item =>
        {
            var ativo = ativosPorId[item.AtivoId];
            return new AssetInput(
                Codigo: ativo.Codigo,
                Peso: item.Peso,
                RetornoEsperadoAnual: (double)(ativo.RetornoEsperadoAA ?? DefaultRetorno(ativo.TipoAtivo)),
                VolatilidadeAnual: (double)(ativo.VolatilidadeAA ?? DefaultVolatilidade(ativo.TipoAtivo))
            );
        }).ToList();

        var simulationInput = new SimulationInput(
            Ativos: assetInputs,
            ValorCarteira: carteira.ValorTotal,
            NumeroCenarios: request.NumeroCenarios,
            HorizonteDias: request.HorizonteDias,
            NivelConfianca: request.NivelConfianca,
            MatrizCorrelacao: null, // extensível: pode ser calculada a partir de Historico_Precos
            Seed: request.Seed
        );

        var output = _engine.Simulate(simulationInput);

        var simulacao = new Simulacao
        {
            CarteiraId = carteira.CarteiraId,
            DataExecucao = DateTime.UtcNow,
            NumeroCenarios = request.NumeroCenarios,
            HorizonteDias = request.HorizonteDias,
            NivelConfianca = request.NivelConfianca,
            ValorCarteira = carteira.ValorTotal,
            VaRAbsoluto = output.VaRAbsoluto,
            VaRPercentual = output.VaRPercentual,
            CVaR = output.CVaR,
            RetornoMedioSimulado = output.RetornoMedioSimulado,
            SeedAleatoria = request.Seed
        };
        await _simulacaoRepository.AddAsync(simulacao, ct);

        var histograma = BuildHistograma(output.RetornosSimulados, buckets: 30);

        return new SimulacaoResultDto(
            SimulacaoId: simulacao.SimulacaoId,
            CarteiraId: carteira.CarteiraId,
            DataExecucao: simulacao.DataExecucao,
            NumeroCenarios: request.NumeroCenarios,
            HorizonteDias: request.HorizonteDias,
            NivelConfianca: request.NivelConfianca,
            ValorCarteira: carteira.ValorTotal,
            VaRAbsoluto: output.VaRAbsoluto,
            VaRPercentual: output.VaRPercentual,
            CVaR: output.CVaR,
            RetornoMedioSimulado: output.RetornoMedioSimulado,
            DesvioPadraoSimulado: output.DesvioPadraoSimulado,
            PiorCenario: output.PiorCenario,
            MelhorCenario: output.MelhorCenario,
            Histograma: histograma
        );
    }

    private static List<HistogramaFaixaDto> BuildHistograma(IReadOnlyList<double> retornos, int buckets)
    {
        if (retornos.Count == 0) return new List<HistogramaFaixaDto>();

        double min = retornos.Min();
        double max = retornos.Max();
        double largura = (max - min) / buckets;
        if (largura <= 0) largura = 0.0001;

        var contagens = new int[buckets];
        foreach (var r in retornos)
        {
            int idx = (int)((r - min) / largura);
            if (idx >= buckets) idx = buckets - 1;
            if (idx < 0) idx = 0;
            contagens[idx]++;
        }

        var resultado = new List<HistogramaFaixaDto>();
        for (int i = 0; i < buckets; i++)
        {
            decimal faixaMin = (decimal)(min + i * largura);
            decimal faixaMax = (decimal)(min + (i + 1) * largura);
            resultado.Add(new HistogramaFaixaDto(faixaMin, faixaMax, contagens[i]));
        }
        return resultado;
    }

    // Valores default conservadores, usados apenas quando o ativo
    // não possui retorno/volatilidade cadastrados explicitamente.
    private static decimal DefaultRetorno(TipoAtivo tipo) => tipo switch
    {
        TipoAtivo.RendaFixa => 0.10m,
        TipoAtivo.Acao => 0.12m,
        TipoAtivo.Derivativo => 0.10m,
        TipoAtivo.Cambio => 0.04m,
        TipoAtivo.Cripto => 0.20m,
        _ => 0.08m
    };

    private static decimal DefaultVolatilidade(TipoAtivo tipo) => tipo switch
    {
        TipoAtivo.RendaFixa => 0.01m,
        TipoAtivo.Acao => 0.30m,
        TipoAtivo.Derivativo => 0.28m,
        TipoAtivo.Cambio => 0.15m,
        TipoAtivo.Cripto => 0.70m,
        _ => 0.20m
    };
}
