using VaR.Application.Interfaces;

namespace VaR.Application.Services;

/// <summary>
/// Motor de cálculo de Value at Risk (VaR) via Simulação de Monte Carlo.
///
/// Modelo utilizado: Movimento Geométrico Browniano (GBM) por ativo,
/// com choques aleatórios correlacionados obtidos por Decomposição de
/// Cholesky sobre a matriz de correlação informada. Cada cenário gera
/// um retorno para cada ativo no horizonte solicitado; o retorno da
/// carteira em cada cenário é a soma ponderada pelos pesos.
///
/// O VaR é obtido pelo percentil (1 - nível de confiança) da distribuição
/// de retornos simulados da carteira (VaR histórico-simulado). O CVaR
/// (Expected Shortfall) é a média dos retornos que ficaram abaixo do VaR.
///
/// Esta classe implementa apenas <see cref="IMonteCarloEngine"/> e não
/// possui qualquer dependência de banco de dados ou web (SOLID - SRP e DIP),
/// o que a torna 100% testável de forma isolada (ver VaR.Tests).
/// </summary>
public sealed class MonteCarloEngine : IMonteCarloEngine
{
    public SimulationOutput Simulate(SimulationInput input)
    {
        ValidateInput(input);

        var n = input.Ativos.Count;
        var random = input.Seed.HasValue ? new Random((int)input.Seed.Value) : new Random();

        // dt em anos (horizonte em dias úteis / 252)
        double dt = input.HorizonteDias / 252.0;

        // Matriz de correlação: usa a informada ou assume identidade (ativos independentes)
        double[,] correlacao = input.MatrizCorrelacao ?? IdentityMatrix(n);
        double[,] cholesky = CholeskyDecomposition(correlacao);

        var retornosCarteira = new double[input.NumeroCenarios];

        for (int cenario = 0; cenario < input.NumeroCenarios; cenario++)
        {
            // 1. Gera choques normais independentes (Box-Muller)
            var choquesIndependentes = new double[n];
            for (int i = 0; i < n; i++)
                choquesIndependentes[i] = NextGaussian(random);

            // 2. Correlaciona os choques via Cholesky: Z_correlacionado = L * Z
            var choquesCorrelacionados = MultiplyLowerTriangular(cholesky, choquesIndependentes);

            // 3. Para cada ativo, aplica o modelo GBM:
            //    r = (mu - 0.5*sigma^2)*dt + sigma*sqrt(dt)*Z
            double retornoCarteiraCenario = 0.0;
            for (int i = 0; i < n; i++)
            {
                var ativo = input.Ativos[i];
                double mu = ativo.RetornoEsperadoAnual;
                double sigma = ativo.VolatilidadeAnual;

                double retornoAtivo = (mu - 0.5 * sigma * sigma) * dt
                                       + sigma * Math.Sqrt(dt) * choquesCorrelacionados[i];

                retornoCarteiraCenario += (double)ativo.Peso * retornoAtivo;
            }

            retornosCarteira[cenario] = retornoCarteiraCenario;
        }

        return BuildOutput(retornosCarteira, input.ValorCarteira, input.NivelConfianca);
    }

    private static SimulationOutput BuildOutput(double[] retornos, decimal valorCarteira, decimal nivelConfianca)
    {
        var ordenados = (double[])retornos.Clone();
        Array.Sort(ordenados);

        int n = ordenados.Length;
        double alfa = 1.0 - (double)nivelConfianca; // ex.: 0.05 para 95%
        int indiceVaR = Math.Max(0, (int)Math.Floor(alfa * n) - 1);
        indiceVaR = Math.Clamp(indiceVaR, 0, n - 1);

        double retornoNoPercentil = ordenados[indiceVaR];

        // CVaR (Expected Shortfall): média dos retornos abaixo (ou iguais) ao percentil de VaR
        double somaCauda = 0.0;
        int contagemCauda = 0;
        for (int i = 0; i <= indiceVaR; i++)
        {
            somaCauda += ordenados[i];
            contagemCauda++;
        }
        double retornoMedioCauda = contagemCauda > 0 ? somaCauda / contagemCauda : retornoNoPercentil;

        double media = Average(retornos);
        double desvio = StdDev(retornos, media);

        decimal varPercentual = (decimal)(-retornoNoPercentil); // perda expressa como valor positivo
        decimal varAbsoluto = Math.Max(0, valorCarteira * varPercentual);
        decimal cvarAbsoluto = Math.Max(0, valorCarteira * (decimal)(-retornoMedioCauda));

        return new SimulationOutput(
            VaRAbsoluto: Math.Round(varAbsoluto, 2),
            VaRPercentual: Math.Round(varPercentual, 6),
            CVaR: Math.Round(cvarAbsoluto, 2),
            RetornoMedioSimulado: Math.Round((decimal)media, 6),
            DesvioPadraoSimulado: Math.Round((decimal)desvio, 6),
            PiorCenario: Math.Round((decimal)ordenados[0], 6),
            MelhorCenario: Math.Round((decimal)ordenados[^1], 6),
            RetornosSimulados: retornos
        );
    }

    private static void ValidateInput(SimulationInput input)
    {
        if (input.Ativos is null || input.Ativos.Count == 0)
            throw new ArgumentException("A carteira precisa conter ao menos um ativo.", nameof(input));

        var somaPesos = input.Ativos.Sum(a => a.Peso);
        if (Math.Abs(somaPesos - 1m) > 0.0001m)
            throw new ArgumentException($"A soma dos pesos deve ser 1 (100%). Valor informado: {somaPesos}.", nameof(input));

        if (input.NumeroCenarios <= 0)
            throw new ArgumentException("Número de cenários deve ser maior que zero.", nameof(input));

        if (input.HorizonteDias <= 0)
            throw new ArgumentException("Horizonte em dias deve ser maior que zero.", nameof(input));

        if (input.NivelConfianca <= 0 || input.NivelConfianca >= 1)
            throw new ArgumentException("Nível de confiança deve estar entre 0 e 1 (ex.: 0.95).", nameof(input));

        if (input.ValorCarteira <= 0)
            throw new ArgumentException("Valor da carteira deve ser maior que zero.", nameof(input));

        if (input.MatrizCorrelacao is not null)
        {
            int n = input.Ativos.Count;
            if (input.MatrizCorrelacao.GetLength(0) != n || input.MatrizCorrelacao.GetLength(1) != n)
                throw new ArgumentException("Matriz de correlação deve ser NxN, onde N é o número de ativos.", nameof(input));
        }
    }

    // ---------- Utilitários matemáticos ----------

    /// <summary>Gera um número com distribuição normal padrão N(0,1) via transformação Box-Muller.</summary>
    private static double NextGaussian(Random random)
    {
        double u1 = 1.0 - random.NextDouble(); // evita log(0)
        double u2 = random.NextDouble();
        return Math.Sqrt(-2.0 * Math.Log(u1)) * Math.Sin(2.0 * Math.PI * u2);
    }

    private static double[,] IdentityMatrix(int n)
    {
        var m = new double[n, n];
        for (int i = 0; i < n; i++) m[i, i] = 1.0;
        return m;
    }

    /// <summary>
    /// Decomposição de Cholesky: dado uma matriz de correlação simétrica
    /// e positiva-definida, retorna L tal que L * L^T = matriz original.
    /// Usada para transformar choques aleatórios independentes em
    /// choques correlacionados entre os ativos da carteira.
    /// </summary>
    private static double[,] CholeskyDecomposition(double[,] matrix)
    {
        int n = matrix.GetLength(0);
        var l = new double[n, n];

        for (int i = 0; i < n; i++)
        {
            for (int j = 0; j <= i; j++)
            {
                double soma = 0.0;
                for (int k = 0; k < j; k++)
                    soma += l[i, k] * l[j, k];

                if (i == j)
                {
                    double valor = matrix[i, i] - soma;
                    l[i, j] = valor > 0 ? Math.Sqrt(valor) : 0.0;
                }
                else
                {
                    l[i, j] = l[j, j] != 0 ? (matrix[i, j] - soma) / l[j, j] : 0.0;
                }
            }
        }
        return l;
    }

    private static double[] MultiplyLowerTriangular(double[,] l, double[] z)
    {
        int n = z.Length;
        var resultado = new double[n];
        for (int i = 0; i < n; i++)
        {
            double soma = 0.0;
            for (int j = 0; j <= i; j++)
                soma += l[i, j] * z[j];
            resultado[i] = soma;
        }
        return resultado;
    }

    private static double Average(double[] values)
    {
        double soma = 0;
        foreach (var v in values) soma += v;
        return soma / values.Length;
    }

    private static double StdDev(double[] values, double media)
    {
        double somaQuadrados = 0;
        foreach (var v in values) somaQuadrados += (v - media) * (v - media);
        return Math.Sqrt(somaQuadrados / values.Length);
    }
}
