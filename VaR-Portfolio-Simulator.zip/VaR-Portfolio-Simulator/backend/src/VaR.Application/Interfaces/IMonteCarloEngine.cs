using VaR.Domain.Entities;

namespace VaR.Application.Interfaces;

/// <summary>
/// Contrato do motor de cálculo de risco (Value at Risk via Monte Carlo).
/// Depende apenas de tipos de domínio, sem qualquer referência a
/// EF Core, ASP.NET ou infraestrutura — princípio da Inversão de
/// Dependência (SOLID: D). Isso permite testar o motor isoladamente
/// e trocar a camada de API sem tocar na regra de negócio.
/// </summary>
public interface IMonteCarloEngine
{
    /// <summary>
    /// Executa a simulação de Monte Carlo para uma carteira composta
    /// por múltiplos ativos correlacionados e retorna as estatísticas
    /// de risco (VaR, CVaR, distribuição de retornos).
    /// </summary>
    SimulationOutput Simulate(SimulationInput input);
}

/// <summary>Entrada do motor: parâmetros estatísticos de cada ativo da carteira.</summary>
public sealed record AssetInput(
    string Codigo,
    decimal Peso,
    double RetornoEsperadoAnual,
    double VolatilidadeAnual
);

public sealed record SimulationInput(
    IReadOnlyList<AssetInput> Ativos,
    decimal ValorCarteira,
    int NumeroCenarios,
    int HorizonteDias,
    decimal NivelConfianca,
    double[,]? MatrizCorrelacao = null,
    long? Seed = null
);

public sealed record SimulationOutput(
    decimal VaRAbsoluto,
    decimal VaRPercentual,
    decimal CVaR,
    decimal RetornoMedioSimulado,
    decimal DesvioPadraoSimulado,
    decimal PiorCenario,
    decimal MelhorCenario,
    IReadOnlyList<double> RetornosSimulados
);
