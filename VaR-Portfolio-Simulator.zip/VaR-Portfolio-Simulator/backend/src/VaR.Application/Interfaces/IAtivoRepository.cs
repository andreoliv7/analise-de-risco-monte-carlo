using VaR.Domain.Entities;

namespace VaR.Application.Interfaces;

public interface IAtivoRepository
{
    Task<Ativo?> GetByIdAsync(int ativoId, CancellationToken ct = default);
    Task<IReadOnlyList<Ativo>> GetAllAsync(CancellationToken ct = default);
    Task<IReadOnlyList<Ativo>> GetByIdsAsync(IEnumerable<int> ids, CancellationToken ct = default);
    Task<Ativo> AddAsync(Ativo ativo, CancellationToken ct = default);
    Task UpdateAsync(Ativo ativo, CancellationToken ct = default);
    Task DeleteAsync(int ativoId, CancellationToken ct = default);

    /// <summary>Retorna as cotações históricas ordenadas por data, usadas para
    /// estimar retorno/volatilidade e a matriz de correlação entre ativos.</summary>
    Task<IReadOnlyList<HistoricoPreco>> GetHistoricoAsync(int ativoId, CancellationToken ct = default);
}
