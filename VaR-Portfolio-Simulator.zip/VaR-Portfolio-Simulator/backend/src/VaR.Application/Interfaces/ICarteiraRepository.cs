using VaR.Domain.Entities;

namespace VaR.Application.Interfaces;

public interface ICarteiraRepository
{
    Task<Carteira?> GetByIdAsync(int carteiraId, bool incluirItens = true, CancellationToken ct = default);
    Task<IReadOnlyList<Carteira>> GetAllAsync(CancellationToken ct = default);
    Task<Carteira> AddAsync(Carteira carteira, CancellationToken ct = default);
    Task UpdateAsync(Carteira carteira, CancellationToken ct = default);
    Task DeleteAsync(int carteiraId, CancellationToken ct = default);
}
