using VaR.Domain.Entities;

namespace VaR.Application.Interfaces;

public interface ISimulacaoRepository
{
    Task<Simulacao> AddAsync(Simulacao simulacao, CancellationToken ct = default);
    Task<IReadOnlyList<Simulacao>> GetByCarteiraIdAsync(int carteiraId, CancellationToken ct = default);
    Task<Simulacao?> GetByIdAsync(long simulacaoId, CancellationToken ct = default);
}
