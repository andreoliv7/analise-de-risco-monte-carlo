namespace VaR.Application.DTOs;

public record CarteiraItemDto(int AtivoId, string? CodigoAtivo, decimal Peso);

public record CarteiraDto(
    int CarteiraId,
    string NomeCarteira,
    decimal ValorTotal,
    DateTime DataCriacao,
    List<CarteiraItemDto> Itens
);

public record CarteiraCreateDto(
    string NomeCarteira,
    decimal ValorTotal,
    List<CarteiraItemDto> Itens
);

public record CarteiraUpdateDto(
    string NomeCarteira,
    decimal ValorTotal,
    List<CarteiraItemDto> Itens
);
