namespace VaR.Application.DTOs;

public record AtivoDto(
    int AtivoId,
    string Codigo,
    string Nome,
    string TipoAtivo,
    string Moeda,
    decimal? RetornoEsperadoAA,
    decimal? VolatilidadeAA
);

public record AtivoCreateDto(
    string Codigo,
    string Nome,
    string TipoAtivo,
    string Moeda,
    decimal? RetornoEsperadoAA,
    decimal? VolatilidadeAA
);
