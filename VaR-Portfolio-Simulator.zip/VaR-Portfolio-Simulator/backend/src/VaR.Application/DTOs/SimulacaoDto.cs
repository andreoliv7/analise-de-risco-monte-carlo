namespace VaR.Application.DTOs;

/// <summary>
/// Parâmetros de entrada para disparar uma Simulação de Monte Carlo
/// sobre uma carteira já cadastrada.
/// </summary>
public record SimulacaoRequestDto(
    int CarteiraId,
    int NumeroCenarios = 10_000,
    int HorizonteDias = 1,
    decimal NivelConfianca = 0.95m,
    long? Seed = null
);

/// <summary>
/// Resultado consolidado de uma simulação, incluindo os dados
/// necessários para o frontend plotar o histograma de retornos.
/// </summary>
public record SimulacaoResultDto(
    long SimulacaoId,
    int CarteiraId,
    DateTime DataExecucao,
    int NumeroCenarios,
    int HorizonteDias,
    decimal NivelConfianca,
    decimal ValorCarteira,
    decimal VaRAbsoluto,
    decimal VaRPercentual,
    decimal CVaR,
    decimal RetornoMedioSimulado,
    decimal DesvioPadraoSimulado,
    decimal PiorCenario,
    decimal MelhorCenario,
    List<HistogramaFaixaDto> Histograma
);

/// <summary>Uma faixa (bucket) do histograma de retornos simulados.</summary>
public record HistogramaFaixaDto(decimal RetornoMinimo, decimal RetornoMaximo, int Frequencia);
