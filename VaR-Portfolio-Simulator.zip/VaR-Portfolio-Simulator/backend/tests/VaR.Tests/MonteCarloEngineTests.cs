using FluentAssertions;
using VaR.Application.Interfaces;
using VaR.Application.Services;
using Xunit;

namespace VaR.Tests;

/// <summary>
/// Suíte de testes unitários do motor de Monte Carlo (VaR.Application.Services.MonteCarloEngine).
///
/// >> Gerada com apoio do Claude (Anthropic) <<
/// Utilizamos o Claude para: (1) mapear os casos de borda relevantes para
/// um motor estatístico (ex.: ativo único vs. carteira diversificada,
/// validação de pesos, reprodutibilidade via seed, sensibilidade do VaR
/// ao nível de confiança); (2) gerar o esqueleto inicial dos testes em
/// xUnit + FluentAssertions; e (3) revisar as asserções estatísticas
/// (tolerâncias, uso de seed fixa) para reduzir flakiness. Todos os
/// testes foram executados e ajustados manualmente antes do commit —
/// ver detalhes da metodologia no README.md, seção "Uso de IA".
/// </summary>
public class MonteCarloEngineTests
{
    private readonly IMonteCarloEngine _engine = new MonteCarloEngine();

    [Fact]
    public void Simulate_CarteiraRendaFixaBaixaVolatilidade_DeveGerarVaRPequeno()
    {
        // Arrange: ativo único de renda fixa, baixíssima volatilidade
        var input = new SimulationInput(
            Ativos: new[] { new AssetInput("CDI", 1.0m, 0.11, 0.005) },
            ValorCarteira: 100_000m,
            NumeroCenarios: 20_000,
            HorizonteDias: 21,
            NivelConfianca: 0.95m,
            Seed: 42
        );

        // Act
        var resultado = _engine.Simulate(input);

        // Assert: VaR de um ativo com volatilidade de 0,5% a.a. deve ser bem pequeno
        resultado.VaRPercentual.Should().BeGreaterThan(0);
        resultado.VaRPercentual.Should().BeLessThan(0.02m);
        resultado.VaRAbsoluto.Should().BeLessThan(2_000m);
    }

    [Fact]
    public void Simulate_CarteiraAcoesAltaVolatilidade_DeveGerarVaRMaiorQueRendaFixa()
    {
        // Arrange
        var inputRendaFixa = new SimulationInput(
            Ativos: new[] { new AssetInput("CDI", 1.0m, 0.11, 0.005) },
            ValorCarteira: 100_000m, NumeroCenarios: 20_000, HorizonteDias: 21, NivelConfianca: 0.95m, Seed: 1);

        var inputAcoes = new SimulationInput(
            Ativos: new[] { new AssetInput("PETR4", 1.0m, 0.14, 0.36) },
            ValorCarteira: 100_000m, NumeroCenarios: 20_000, HorizonteDias: 21, NivelConfianca: 0.95m, Seed: 1);

        // Act
        var varRendaFixa = _engine.Simulate(inputRendaFixa).VaRPercentual;
        var varAcoes = _engine.Simulate(inputAcoes).VaRPercentual;

        // Assert: carteira mais volátil deve ter VaR percentual maior
        varAcoes.Should().BeGreaterThan(varRendaFixa);
    }

    [Fact]
    public void Simulate_MesmaSeed_DeveSerReprodutivel()
    {
        var input = new SimulationInput(
            Ativos: new[] { new AssetInput("PETR4", 1.0m, 0.14, 0.36) },
            ValorCarteira: 50_000m, NumeroCenarios: 5_000, HorizonteDias: 10, NivelConfianca: 0.95m, Seed: 123);

        var resultado1 = _engine.Simulate(input);
        var resultado2 = _engine.Simulate(input);

        resultado1.VaRAbsoluto.Should().Be(resultado2.VaRAbsoluto);
        resultado1.RetornoMedioSimulado.Should().Be(resultado2.RetornoMedioSimulado);
    }

    [Fact]
    public void Simulate_CarteiraDiversificada_PesosDevemSomarUm()
    {
        var input = new SimulationInput(
            Ativos: new[]
            {
                new AssetInput("CDI", 0.5m, 0.11, 0.005),
                new AssetInput("PETR4", 0.3m, 0.14, 0.36),
                new AssetInput("WINFUT", 0.2m, 0.13, 0.28)
            },
            ValorCarteira: 200_000m, NumeroCenarios: 10_000, HorizonteDias: 1, NivelConfianca: 0.95m, Seed: 7);

        var resultado = _engine.Simulate(input);

        resultado.VaRAbsoluto.Should().BeGreaterThan(0);
        resultado.RetornosSimulados.Should().HaveCount(10_000);
    }

    [Fact]
    public void Simulate_PesosNaoSomamUm_DeveLancarArgumentException()
    {
        var input = new SimulationInput(
            Ativos: new[]
            {
                new AssetInput("CDI", 0.5m, 0.11, 0.005),
                new AssetInput("PETR4", 0.3m, 0.14, 0.36) // soma = 0.8, inválido
            },
            ValorCarteira: 100_000m, NumeroCenarios: 1_000, HorizonteDias: 1, NivelConfianca: 0.95m);

        Action act = () => _engine.Simulate(input);

        act.Should().Throw<ArgumentException>().WithMessage("*soma dos pesos*");
    }

    [Fact]
    public void Simulate_ListaDeAtivosVazia_DeveLancarArgumentException()
    {
        var input = new SimulationInput(
            Ativos: Array.Empty<AssetInput>(),
            ValorCarteira: 100_000m, NumeroCenarios: 1_000, HorizonteDias: 1, NivelConfianca: 0.95m);

        Action act = () => _engine.Simulate(input);

        act.Should().Throw<ArgumentException>().WithMessage("*ao menos um ativo*");
    }

    [Theory]
    [InlineData(0)]
    [InlineData(-100)]
    public void Simulate_NumeroCenariosInvalido_DeveLancarArgumentException(int numeroCenarios)
    {
        var input = new SimulationInput(
            Ativos: new[] { new AssetInput("CDI", 1.0m, 0.11, 0.005) },
            ValorCarteira: 100_000m, NumeroCenarios: numeroCenarios, HorizonteDias: 1, NivelConfianca: 0.95m);

        Action act = () => _engine.Simulate(input);

        act.Should().Throw<ArgumentException>().WithMessage("*cenários*");
    }

    [Fact]
    public void Simulate_ValorCarteiraZeroOuNegativo_DeveLancarArgumentException()
    {
        var input = new SimulationInput(
            Ativos: new[] { new AssetInput("CDI", 1.0m, 0.11, 0.005) },
            ValorCarteira: 0m, NumeroCenarios: 1_000, HorizonteDias: 1, NivelConfianca: 0.95m);

        Action act = () => _engine.Simulate(input);

        act.Should().Throw<ArgumentException>().WithMessage("*carteira deve ser maior que zero*");
    }

    [Theory]
    [InlineData(0.90)]
    [InlineData(0.95)]
    [InlineData(0.99)]
    public void Simulate_NiveisConfiancaValidos_DevemRetornarVaRPositivo(double nivelConfianca)
    {
        var input = new SimulationInput(
            Ativos: new[] { new AssetInput("PETR4", 1.0m, 0.14, 0.36) },
            ValorCarteira: 100_000m, NumeroCenarios: 15_000, HorizonteDias: 21,
            NivelConfianca: (decimal)nivelConfianca, Seed: 99);

        var resultado = _engine.Simulate(input);

        resultado.VaRAbsoluto.Should().BeGreaterThan(0);
    }

    [Fact]
    public void Simulate_NivelConfiancaMaisAlto_DeveGerarVaRMaiorOuIgual()
    {
        // Quanto maior o nível de confiança, mais "para dentro da cauda" o VaR é medido,
        // logo o VaR a 99% deve ser >= VaR a 90% para a mesma carteira/seed.
        var baseInput = new SimulationInput(
            Ativos: new[] { new AssetInput("PETR4", 1.0m, 0.14, 0.36) },
            ValorCarteira: 100_000m, NumeroCenarios: 30_000, HorizonteDias: 21,
            NivelConfianca: 0.90m, Seed: 555);

        var input99 = baseInput with { NivelConfianca = 0.99m };

        var var90 = _engine.Simulate(baseInput).VaRAbsoluto;
        var var99 = _engine.Simulate(input99).VaRAbsoluto;

        var99.Should().BeGreaterOrEqualTo(var90);
    }

    [Fact]
    public void Simulate_CVaR_DeveSerMaiorOuIgualAoVaR()
    {
        // Expected Shortfall (CVaR) é, por definição, a perda média na cauda
        // além do VaR — portanto deve ser sempre >= VaR absoluto.
        var input = new SimulationInput(
            Ativos: new[] { new AssetInput("WINFUT", 1.0m, 0.13, 0.28) },
            ValorCarteira: 100_000m, NumeroCenarios: 20_000, HorizonteDias: 10, NivelConfianca: 0.95m, Seed: 2024);

        var resultado = _engine.Simulate(input);

        resultado.CVaR.Should().BeGreaterOrEqualTo(resultado.VaRAbsoluto);
    }
}
