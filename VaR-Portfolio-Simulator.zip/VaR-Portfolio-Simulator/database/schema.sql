/* ============================================================
   Sistema de Análise de Risco de Carteira (VaR) - SQL Server
   Modelagem relacional
   ============================================================ */

IF DB_ID('VarPortfolioDb') IS NULL
BEGIN
    CREATE DATABASE VarPortfolioDb;
END
GO

USE VarPortfolioDb;
GO

-- ============================================================
-- Tabela: Ativos
-- Cadastro dos ativos financeiros (renda fixa e derivativos)
-- ============================================================
CREATE TABLE Ativos (
    AtivoId            INT IDENTITY(1,1) PRIMARY KEY,
    Codigo              VARCHAR(20)     NOT NULL UNIQUE,      -- Ex: PETR4, CDI, WINZ24
    Nome                VARCHAR(150)    NOT NULL,
    TipoAtivo           TINYINT         NOT NULL,             -- 1=RendaFixa,2=Acao,3=Derivativo,4=Cambio,5=Cripto
    Moeda               CHAR(3)         NOT NULL DEFAULT 'BRL',
    RetornoEsperadoAA   DECIMAL(9,6)    NULL,                 -- usado para renda fixa (taxa contratada)
    VolatilidadeAA      DECIMAL(9,6)    NULL,                 -- volatilidade anualizada histórica
    DataCadastro        DATETIME2       NOT NULL DEFAULT SYSUTCDATETIME(),
    Ativo               BIT             NOT NULL DEFAULT 1
);
GO

-- ============================================================
-- Tabela: Historico_Precos
-- Série histórica de preços/cotações usada para estimar
-- retorno médio, volatilidade e correlação entre ativos
-- ============================================================
CREATE TABLE Historico_Precos (
    HistoricoId     BIGINT IDENTITY(1,1) PRIMARY KEY,
    AtivoId         INT             NOT NULL,
    DataReferencia  DATE            NOT NULL,
    PrecoFechamento DECIMAL(18,6)   NOT NULL,
    CONSTRAINT FK_Historico_Ativo FOREIGN KEY (AtivoId) REFERENCES Ativos(AtivoId),
    CONSTRAINT UQ_Historico UNIQUE (AtivoId, DataReferencia)
);
GO
CREATE INDEX IX_Historico_Ativo_Data ON Historico_Precos(AtivoId, DataReferencia);
GO

-- ============================================================
-- Tabela: Carteiras
-- ============================================================
CREATE TABLE Carteiras (
    CarteiraId      INT IDENTITY(1,1) PRIMARY KEY,
    NomeCarteira    VARCHAR(150)    NOT NULL,
    UsuarioId       INT             NULL,
    ValorTotal      DECIMAL(18,2)   NOT NULL DEFAULT 0,
    DataCriacao     DATETIME2       NOT NULL DEFAULT SYSUTCDATETIME(),
    DataAtualizacao DATETIME2       NULL
);
GO

-- ============================================================
-- Tabela: Carteira_Itens
-- ============================================================
CREATE TABLE Carteira_Itens (
    CarteiraItemId  INT IDENTITY(1,1) PRIMARY KEY,
    CarteiraId      INT             NOT NULL,
    AtivoId         INT             NOT NULL,
    Peso            DECIMAL(9,6)    NOT NULL,
    Quantidade      DECIMAL(18,6)   NULL,
    PrecoEntrada    DECIMAL(18,6)   NULL,
    CONSTRAINT FK_Item_Carteira FOREIGN KEY (CarteiraId) REFERENCES Carteiras(CarteiraId) ON DELETE CASCADE,
    CONSTRAINT FK_Item_Ativo    FOREIGN KEY (AtivoId)    REFERENCES Ativos(AtivoId),
    CONSTRAINT UQ_Item_CarteiraAtivo UNIQUE (CarteiraId, AtivoId),
    CONSTRAINT CK_Item_Peso CHECK (Peso >= 0 AND Peso <= 1)
);
GO

-- ============================================================
-- Tabela: Simulacoes
-- ============================================================
CREATE TABLE Simulacoes (
    SimulacaoId          BIGINT IDENTITY(1,1) PRIMARY KEY,
    CarteiraId           INT             NOT NULL,
    DataExecucao         DATETIME2       NOT NULL DEFAULT SYSUTCDATETIME(),
    NumeroCenarios       INT             NOT NULL,
    HorizonteDias        INT             NOT NULL,
    NivelConfianca       DECIMAL(5,4)    NOT NULL,
    ValorCarteira        DECIMAL(18,2)   NOT NULL,
    VaRAbsoluto          DECIMAL(18,2)   NOT NULL,
    VaRPercentual        DECIMAL(9,6)    NOT NULL,
    CVaR                 DECIMAL(18,2)   NULL,
    RetornoMedioSimulado DECIMAL(9,6)    NULL,
    SeedAleatoria         BIGINT          NULL,
    CONSTRAINT FK_Simulacao_Carteira FOREIGN KEY (CarteiraId) REFERENCES Carteiras(CarteiraId)
);
GO
CREATE INDEX IX_Simulacao_Carteira_Data ON Simulacoes(CarteiraId, DataExecucao DESC);
GO

-- ============================================================
-- Dados de exemplo (seed)
-- ============================================================
INSERT INTO Ativos (Codigo, Nome, TipoAtivo, Moeda, RetornoEsperadoAA, VolatilidadeAA) VALUES
('CDI',    'CDI - Renda Fixa Pós-fixada',        1, 'BRL', 0.1075, 0.0050),
('TESOURO','Tesouro Prefixado 2029',             1, 'BRL', 0.1150, 0.0120),
('PETR4',  'Petrobras PN',                       2, 'BRL', 0.1400, 0.3600),
('VALE3',  'Vale ON',                            2, 'BRL', 0.1200, 0.3300),
('WINFUT', 'Mini Índice Futuro (Derivativo)',    3, 'BRL', 0.1300, 0.2800),
('WDOFUT', 'Mini Dólar Futuro (Derivativo)',     3, 'BRL', 0.0500, 0.1600);
GO
