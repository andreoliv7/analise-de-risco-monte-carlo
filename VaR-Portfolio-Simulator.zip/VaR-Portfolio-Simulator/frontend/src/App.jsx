import React, { useEffect, useState } from "react";
import PortfolioBuilder from "./components/PortfolioBuilder";
import SimulationResults from "./components/SimulationResults";
import { varApi } from "./api/varApi";

export default function App() {
  const [ativosDisponiveis, setAtivosDisponiveis] = useState([]);
  const [resultado, setResultado] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [carteiraIdAtual, setCarteiraIdAtual] = useState(null);

  useEffect(() => {
    varApi
      .listarAtivos()
      .then(setAtivosDisponiveis)
      .catch(() => setError("Não foi possível carregar a lista de ativos da API."));
  }, []);

  async function handleSimular({ carteira, parametros }) {
    setLoading(true);
    setError(null);
    setResultado(null);
    try {
      // 1. Cria (ou atualiza, se já existir) a carteira no backend
      const carteiraSalva = carteiraIdAtual
        ? await varApi.atualizarCarteira(carteiraIdAtual, carteira).then(() => ({ carteiraId: carteiraIdAtual }))
        : await varApi.criarCarteira(carteira);

      setCarteiraIdAtual(carteiraSalva.carteiraId);

      // 2. Dispara a Simulação de Monte Carlo sobre a carteira salva
      const resultadoSimulacao = await varApi.simular({
        carteiraId: carteiraSalva.carteiraId,
        ...parametros,
      });

      setResultado(resultadoSimulacao);
    } catch (err) {
      setError(err.message || "Falha ao executar a simulação.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="app-shell">
      <header className="app-header">
        <h1>Análise de Risco de Carteira — VaR via Monte Carlo</h1>
        <p>
          Monte uma carteira combinando renda fixa e derivativos, defina os pesos
          e simule milhares de cenários de preços futuros para estimar a perda
          máxima esperada (Value at Risk) em um horizonte de tempo.
        </p>
      </header>

      <div className="app-body">
        <PortfolioBuilder
          ativosDisponiveis={ativosDisponiveis}
          onSimular={handleSimular}
          loading={loading}
        />
        <SimulationResults resultado={resultado} loading={loading} error={error} />
      </div>
    </div>
  );
}
