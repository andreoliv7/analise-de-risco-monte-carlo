// Camada de acesso à API REST em C# (.NET). Centraliza a URL base
// e o tratamento de erros HTTP para todos os componentes do dashboard.

const API_BASE_URL = process.env.REACT_APP_API_URL || "https://localhost:5001/api";

async function request(path, options = {}) {
  const response = await fetch(`${API_BASE_URL}${path}`, {
    headers: { "Content-Type": "application/json" },
    ...options,
  });

  if (!response.ok) {
    const texto = await response.text().catch(() => "");
    throw new Error(texto || `Erro na requisição: ${response.status}`);
  }

  if (response.status === 204) return null;
  return response.json();
}

export const varApi = {
  listarAtivos: () => request("/ativos"),

  criarCarteira: (payload) =>
    request("/carteiras", { method: "POST", body: JSON.stringify(payload) }),

  atualizarCarteira: (id, payload) =>
    request(`/carteiras/${id}`, { method: "PUT", body: JSON.stringify(payload) }),

  listarCarteiras: () => request("/carteiras"),

  simular: (payload) =>
    request("/simulacoes/simular", { method: "POST", body: JSON.stringify(payload) }),
};
