import React, { useState, useMemo } from "react";
import AssetRow from "./AssetRow";

let nextRowId = 1;

/**
 * Formulário de montagem da carteira: adicionar ativos, definir peso (%)
 * de cada um, valor total da carteira e parâmetros da simulação
 * (nº de cenários, horizonte em dias, nível de confiança).
 * Ao clicar em "Simular", monta o payload esperado pela API e delega
 * a chamada para o componente pai via onSimular.
 */
export default function PortfolioBuilder({ ativosDisponiveis, onSimular, loading }) {
  const [nomeCarteira, setNomeCarteira] = useState("Minha Carteira");
  const [valorTotal, setValorTotal] = useState("100000");
  const [itens, setItens] = useState([{ id: nextRowId++, ativoId: "", pesoPercentual: "" }]);
  const [numeroCenarios, setNumeroCenarios] = useState(10000);
  const [horizonteDias, setHorizonteDias] = useState(21);
  const [nivelConfianca, setNivelConfianca] = useState(0.95);

  const somaPesos = useMemo(
    () => itens.reduce((acc, i) => acc + (parseFloat(i.pesoPercentual) || 0), 0),
    [itens]
  );
  const pesosValidos = Math.abs(somaPesos - 100) < 0.01 && itens.length > 0;

  function adicionarAtivo() {
    setItens([...itens, { id: nextRowId++, ativoId: "", pesoPercentual: "" }]);
  }

  function atualizarItem(id, novoItem) {
    setItens(itens.map((i) => (i.id === id ? novoItem : i)));
  }

  function removerItem(id) {
    setItens(itens.filter((i) => i.id !== id));
  }

  function handleSimular() {
    const payload = {
      carteira: {
        nomeCarteira,
        valorTotal: parseFloat(valorTotal) || 0,
        itens: itens
          .filter((i) => i.ativoId)
          .map((i) => ({
            ativoId: parseInt(i.ativoId, 10),
            peso: (parseFloat(i.pesoPercentual) || 0) / 100,
          })),
      },
      parametros: {
        numeroCenarios: parseInt(numeroCenarios, 10),
        horizonteDias: parseInt(horizonteDias, 10),
        nivelConfianca: parseFloat(nivelConfianca),
      },
    };
    onSimular(payload);
  }

  return (
    <div className="panel">
      <h2>Montagem da carteira</h2>

      <div className="field">
        <label>Nome da carteira</label>
        <input value={nomeCarteira} onChange={(e) => setNomeCarteira(e.target.value)} />
      </div>

      <div className="field">
        <label>Valor total investido (R$)</label>
        <input
          type="number"
          min="0"
          value={valorTotal}
          onChange={(e) => setValorTotal(e.target.value)}
        />
      </div>

      <div className="field">
        <label>Ativos e pesos</label>
        {itens.map((item) => (
          <AssetRow
            key={item.id}
            item={item}
            ativosDisponiveis={ativosDisponiveis}
            onChange={(novo) => atualizarItem(item.id, novo)}
            onRemove={() => removerItem(item.id)}
          />
        ))}
        <div className={`weight-total ${itens.length ? (pesosValidos ? "valid" : "invalid") : ""}`}>
          Soma dos pesos: {somaPesos.toFixed(1)}% {pesosValidos ? "✓" : "(deve totalizar 100%)"}
        </div>
      </div>

      <button type="button" className="btn btn-secondary" onClick={adicionarAtivo}>
        + Adicionar ativo
      </button>

      <h2>Parâmetros da simulação</h2>

      <div className="field">
        <label>Número de cenários (Monte Carlo)</label>
        <input
          type="number"
          min="1000"
          step="1000"
          value={numeroCenarios}
          onChange={(e) => setNumeroCenarios(e.target.value)}
        />
      </div>

      <div className="field">
        <label>Horizonte (dias úteis)</label>
        <input
          type="number"
          min="1"
          value={horizonteDias}
          onChange={(e) => setHorizonteDias(e.target.value)}
        />
      </div>

      <div className="field">
        <label>Nível de confiança</label>
        <select value={nivelConfianca} onChange={(e) => setNivelConfianca(e.target.value)}>
          <option value="0.90">90%</option>
          <option value="0.95">95%</option>
          <option value="0.99">99%</option>
        </select>
      </div>

      <button
        type="button"
        className="btn btn-primary"
        disabled={!pesosValidos || loading}
        onClick={handleSimular}
      >
        {loading ? "Simulando…" : "Simular"}
      </button>
    </div>
  );
}
