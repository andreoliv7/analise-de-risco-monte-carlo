import React from "react";
import HistogramChart from "./HistogramChart";

const formatBRL = (v) =>
  new Intl.NumberFormat("pt-BR", { style: "currency", currency: "BRL" }).format(v);
const formatPct = (v) => `${(v * 100).toFixed(2)}%`;

/**
 * Exibe os resultados de uma simulação de Monte Carlo: cartões de
 * métrica (VaR, CVaR, retorno médio, pior cenário) e o histograma
 * de distribuição de retornos simulados.
 */
export default function SimulationResults({ resultado, loading, error }) {
  if (loading) {
    return <div className="results-empty">Rodando {" "}
      <strong style={{ color: "#3FA9F5", marginLeft: 4 }}>milhares de cenários</strong>…
    </div>;
  }

  if (error) {
    return (
      <div className="panel">
        <div className="error-banner">{error}</div>
      </div>
    );
  }

  if (!resultado) {
    return (
      <div className="results-empty">
        Monte a carteira ao lado, defina os pesos e clique em <strong>Simular</strong><br />
        para calcular o Value at Risk.
      </div>
    );
  }

  return (
    <div className="panel">
      <h2>
        Resultado — {resultado.numeroCenarios.toLocaleString("pt-BR")} cenários ·{" "}
        {resultado.horizonteDias} dia(s) · {formatPct(resultado.nivelConfianca)} de confiança
      </h2>

      <div className="metric-grid">
        <div className="metric-card risk">
          <div className="label">Value at Risk (VaR)</div>
          <div className="value">{formatBRL(resultado.varAbsoluto)}</div>
          <div className="sub">{formatPct(resultado.varPercentual)} do valor da carteira</div>
        </div>

        <div className="metric-card risk">
          <div className="label">CVaR (Expected Shortfall)</div>
          <div className="value">{formatBRL(resultado.cVaR)}</div>
          <div className="sub">perda média além do VaR</div>
        </div>

        <div className="metric-card">
          <div className="label">Retorno médio simulado</div>
          <div className="value">{formatPct(resultado.retornoMedioSimulado)}</div>
          <div className="sub">σ = {formatPct(resultado.desvioPadraoSimulado)}</div>
        </div>

        <div className="metric-card">
          <div className="label">Valor da carteira</div>
          <div className="value">{formatBRL(resultado.valorCarteira)}</div>
          <div className="sub">base da simulação</div>
        </div>
      </div>

      <div className="chart-panel">
        <h3>Distribuição de retornos simulados</h3>
        <p className="chart-note">
          Em vermelho, a cauda de cenários de perda usada para calcular o VaR / CVaR.
        </p>
        <HistogramChart histograma={resultado.histograma} varPercentual={resultado.varPercentual} />
        <div className="stats-row">
          <span>Pior cenário: <strong>{formatPct(resultado.piorCenario)}</strong></span>
          <span>Melhor cenário: <strong>{formatPct(resultado.melhorCenario)}</strong></span>
        </div>
      </div>
    </div>
  );
}
