import React from "react";

/**
 * Uma linha da carteira: seleção do ativo + peso percentual (%).
 * Componente controlado — todo o estado vive no PortfolioBuilder pai.
 */
export default function AssetRow({ item, ativosDisponiveis, onChange, onRemove }) {
  return (
    <div className="asset-row">
      <select
        value={item.ativoId}
        onChange={(e) => onChange({ ...item, ativoId: e.target.value })}
      >
        <option value="">Selecione um ativo…</option>
        {ativosDisponiveis.map((a) => (
          <option key={a.ativoId} value={a.ativoId}>
            {a.codigo} — {a.tipoAtivo}
          </option>
        ))}
      </select>

      <input
        type="number"
        min="0"
        max="100"
        step="1"
        placeholder="Peso %"
        value={item.pesoPercentual}
        onChange={(e) => onChange({ ...item, pesoPercentual: e.target.value })}
      />

      <button type="button" className="remove-btn" onClick={onRemove} aria-label="Remover ativo">
        ×
      </button>
    </div>
  );
}
