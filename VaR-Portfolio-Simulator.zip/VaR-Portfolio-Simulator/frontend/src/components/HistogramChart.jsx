import React from "react";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ReferenceLine,
  ResponsiveContainer,
  Cell,
} from "recharts";

/**
 * Histograma da distribuição de retornos simulados pelo Monte Carlo.
 * Destaca em vermelho as faixas de retorno abaixo do limiar de VaR
 * (a "cauda" de perda usada para o cálculo do risco).
 */
export default function HistogramChart({ histograma, varPercentual }) {
  const limiarPerda = -varPercentual; // retorno abaixo do qual entra na cauda de VaR

  const data = histograma.map((faixa, idx) => ({
    idx,
    faixaCentral: (faixa.retornoMinimo + faixa.retornoMaximo) / 2,
    label: `${(faixa.retornoMinimo * 100).toFixed(1)}%`,
    frequencia: faixa.frequencia,
    naCaudaDeRisco: faixa.retornoMaximo <= limiarPerda,
  }));

  return (
    <ResponsiveContainer width="100%" height={260}>
      <BarChart data={data} margin={{ top: 8, right: 12, left: -12, bottom: 4 }}>
        <CartesianGrid strokeDasharray="3 3" stroke="#232A33" vertical={false} />
        <XAxis
          dataKey="label"
          tick={{ fill: "#8A94A3", fontSize: 11, fontFamily: "IBM Plex Mono" }}
          interval={Math.ceil(data.length / 8)}
          axisLine={{ stroke: "#232A33" }}
          tickLine={false}
        />
        <YAxis
          tick={{ fill: "#8A94A3", fontSize: 11, fontFamily: "IBM Plex Mono" }}
          axisLine={{ stroke: "#232A33" }}
          tickLine={false}
        />
        <Tooltip
          contentStyle={{
            background: "#171C24",
            border: "1px solid #232A33",
            borderRadius: 6,
            fontFamily: "IBM Plex Mono",
            fontSize: 12,
          }}
          labelFormatter={(label) => `Retorno ≈ ${label}`}
          formatter={(value) => [value, "Cenários"]}
        />
        <ReferenceLine x={data.findIndex((d) => !d.naCaudaDeRisco)} stroke="#E5484D" strokeDasharray="4 4" />
        <Bar dataKey="frequencia" radius={[2, 2, 0, 0]}>
          {data.map((d, i) => (
            <Cell key={i} fill={d.naCaudaDeRisco ? "#E5484D" : "#3FA9F5"} />
          ))}
        </Bar>
      </BarChart>
    </ResponsiveContainer>
  );
}
